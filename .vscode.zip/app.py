[{
	"resource": "/c:/Users/sinch/AppData/Local/Programs/Python/Python312/Lib/re/__init__.py",
	"owner": "python",
	"code": {
		"value": "reportMissingImports",
		"target": {
			"$mid": 1,
			"path": "/microsoft/pylance-release/blob/main/docs/diagnostics/reportMissingImports.md",
			"scheme": "https",
			"authority": "github.com"
		}
	},
	"severity": 4,
	"message": "Import \"_sre\" could not be resolved",
	"source": "Pylance",
	"startLineNumber": 127,
	"startColumn": 8,
	"endLineNumber": 127,
	"endColumn": 12
},{
	"resource": "/c:/Users/sinch/AppData/Local/Programs/Python/Python312/Lib/re/__init__.py",
	"owner": "python",
	"code": {
		"value": "reportUndefinedVariable",
		"target": {
			"$mid": 1,
			"path": "/microsoft/pylance-release/blob/main/docs/diagnostics/reportUndefinedVariable.md",
			"scheme": "https",
			"authority": "github.com"
		}
	},
	"severity": 4,
	"message": "\"T\" is not defined",
	"source": "Pylance",
	"startLineNumber": 246,
	"startColumn": 40,
	"endLineNumber": 246,
	"endColumn": 41
},{
	"resource": "/c:/Users/sinch/AppData/Local/Programs/Python/Python312/Lib/re/__init__.py",
	"owner": "python",
	"code": {
		"value": "reportUndefinedVariable",
		"target": {
			"$mid": 1,
			"path": "/microsoft/pylance-release/blob/main/docs/diagnostics/reportUndefinedVariable.md",
			"scheme": "https",
			"authority": "github.com"
		}
	},
	"severity": 4,
	"message": "\"T\" is not defined",
	"source": "Pylance",
	"startLineNumber": 300,
	"startColumn": 20,
	"endLineNumber": 300,
	"endColumn": 21
},{
	"resource": "/c:/Users/sinch/AppData/Local/Programs/Python/Python312/Lib/re/__init__.py",
	"owner": "python",
	"code": {
		"value": "reportUndefinedVariable",
		"target": {
			"$mid": 1,
			"path": "/microsoft/pylance-release/blob/main/docs/diagnostics/reportUndefinedVariable.md",
			"scheme": "https",
			"authority": "github.com"
		}
	},
	"severity": 4,
	"message": "\"DEBUG\" is not defined",
	"source": "Pylance",
	"startLineNumber": 308,
	"startColumn": 20,
	"endLineNumber": 308,
	"endColumn": 25
},{
	"resource": "/c:/Users/sinch/OneDrive/Desktop/mind/routes.py",
	"owner": "python",
	"code": {
		"value": "reportMissingImports",
		"target": {
			"$mid": 1,
			"path": "/microsoft/pylance-release/blob/main/docs/diagnostics/reportMissingImports.md",
			"scheme": "https",
			"authority": "github.com"
		}
	},
	"severity": 4,
	"message": "Import \"ai_analyzer\" could not be resolved",
	"source": "Pylance",
	"startLineNumber": 10,
	"startColumn": 6,
	"endLineNumber": 10,
	"endColumn": 17
}]