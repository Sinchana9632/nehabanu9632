/**
 * Breathing Exercise for MindCare AI
 * Guided breathing exercises for stress relief and mindfulness
 */

class BreathingExercise {
    constructor() {
        this.isActive = false;
        this.currentPhase = 'ready'; // ready, inhale, hold, exhale, pause
        this.currentCycle = 0;
        this.totalCycles = 5;
        this.breathingPattern = {
            inhale: 4,
            holdIn: 4,
            exhale: 6,
            holdOut: 2
        };
        this.animationId = null;
        this.phaseTimeout = null;
        this.completedExercises = parseInt(localStorage.getItem('breathingExercisesCompleted') || '0');
        
        this.initializeElements();
        this.loadSettings();
    }
    
    initializeElements() {
        this.circle = document.getElementById('breathingCircle');
        this.text = document.getElementById('breathingText');
        this.startBtn = document.getElementById('breathingStartBtn');
        this.stopBtn = document.getElementById('breathingStopBtn');
        this.progressRing = document.querySelector('.progress-ring-circle');
        this.cycleCounter = document.getElementById('breathingCycle');
        
        if (this.startBtn) {
            this.startBtn.addEventListener('click', () => this.start());
        }
        
        if (this.stopBtn) {
            this.stopBtn.addEventListener('click', () => this.stop());
        }
        
        // Pattern selection buttons (if added later)
        this.setupPatternButtons();
        
        // Initialize progress ring
        this.initializeProgressRing();
    }
    
    setupPatternButtons() {
        // Common breathing patterns
        this.patterns = {
            '4-4-6-2': { inhale: 4, holdIn: 4, exhale: 6, holdOut: 2, name: 'Relaxing' },
            '4-7-8-0': { inhale: 4, holdIn: 7, exhale: 8, holdOut: 0, name: '4-7-8 Technique' },
            '4-4-4-4': { inhale: 4, holdIn: 4, exhale: 4, holdOut: 4, name: 'Box Breathing' },
            '6-2-6-2': { inhale: 6, holdIn: 2, exhale: 6, holdOut: 2, name: 'Deep Breathing' }
        };
        
        // Create pattern selector if container exists
        const patternContainer = document.getElementById('breathingPatterns');
        if (patternContainer) {
            Object.entries(this.patterns).forEach(([key, pattern]) => {
                const button = document.createElement('button');
                button.className = 'btn btn-sm btn-outline-secondary me-2 mb-2';
                button.textContent = pattern.name;
                button.addEventListener('click', () => this.setPattern(pattern));
                patternContainer.appendChild(button);
            });
        }
    }
    
    initializeProgressRing() {
        if (this.progressRing) {
            const radius = this.progressRing.r.baseVal.value;
            const circumference = radius * 2 * Math.PI;
            
            this.progressRing.style.strokeDasharray = `${circumference} ${circumference}`;
            this.progressRing.style.strokeDashoffset = circumference;
            
            this.circumference = circumference;
        }
    }
    
    setPattern(pattern) {
        if (this.isActive) {
            this.showMessage('Stop the current exercise to change patterns.');
            return;
        }
        
        this.breathingPattern = { ...pattern };
        this.showMessage(`Pattern changed to: ${pattern.name}`);
    }
    
    loadSettings() {
        const savedPattern = localStorage.getItem('breathingPattern');
        if (savedPattern) {
            try {
                this.breathingPattern = JSON.parse(savedPattern);
            } catch (e) {
                console.warn('Could not load saved breathing pattern');
            }
        }
        
        const savedCycles = localStorage.getItem('breathingCycles');
        if (savedCycles) {
            this.totalCycles = parseInt(savedCycles) || 5;
        }
    }
    
    saveSettings() {
        localStorage.setItem('breathingPattern', JSON.stringify(this.breathingPattern));
        localStorage.setItem('breathingCycles', this.totalCycles.toString());
    }
    
    start() {
        if (this.isActive) return;
        
        this.isActive = true;
        this.currentCycle = 0;
        this.currentPhase = 'ready';
        
        this.updateUI();
        this.updateText('Get comfortable and relax...');
        
        // Start after a brief preparation
        setTimeout(() => {
            if (this.isActive) {
                this.nextPhase();
            }
        }, 2000);
        
        // Track exercise start
        this.trackEvent('breathing_exercise_started');
    }
    
    stop() {
        if (!this.isActive) return;
        
        this.isActive = false;
        this.currentPhase = 'ready';
        
        if (this.phaseTimeout) {
            clearTimeout(this.phaseTimeout);
            this.phaseTimeout = null;
        }
        
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
            this.animationId = null;
        }
        
        this.resetVisuals();
        this.updateUI();
        this.updateText('Exercise stopped');
        
        // Show completion if exercise was finished
        if (this.currentCycle > 0) {
            this.showMessage(`Exercise completed! You completed ${this.currentCycle} of ${this.totalCycles} cycles.`);
        }
        
        this.trackEvent('breathing_exercise_stopped', { cycles_completed: this.currentCycle });
    }
    
    nextPhase() {
        if (!this.isActive) return;
        
        switch (this.currentPhase) {
            case 'ready':
                this.currentPhase = 'inhale';
                this.startInhale();
                break;
            case 'inhale':
                this.currentPhase = 'holdIn';
                this.startHold('inhale');
                break;
            case 'holdIn':
                this.currentPhase = 'exhale';
                this.startExhale();
                break;
            case 'exhale':
                this.currentPhase = 'holdOut';
                this.startHold('exhale');
                break;
            case 'holdOut':
                this.currentCycle++;
                this.updateCycleCounter();
                
                if (this.currentCycle >= this.totalCycles) {
                    this.completeExercise();
                } else {
                    this.currentPhase = 'inhale';
                    this.startInhale();
                }
                break;
        }
    }
    
    startInhale() {
        this.updateText('Breathe in slowly...');
        this.animateCircle('inhale', this.breathingPattern.inhale);
        this.updateProgress();
        
        this.phaseTimeout = setTimeout(() => {
            this.nextPhase();
        }, this.breathingPattern.inhale * 1000);
    }
    
    startExhale() {
        this.updateText('Breathe out slowly...');
        this.animateCircle('exhale', this.breathingPattern.exhale);
        this.updateProgress();
        
        this.phaseTimeout = setTimeout(() => {
            this.nextPhase();
        }, this.breathingPattern.exhale * 1000);
    }
    
    startHold(afterPhase) {
        const holdDuration = afterPhase === 'inhale' ? this.breathingPattern.holdIn : this.breathingPattern.holdOut;
        
        if (holdDuration > 0) {
            const holdText = afterPhase === 'inhale' ? 'Hold...' : 'Pause...';
            this.updateText(holdText);
            this.animateCircle('hold', holdDuration);
            
            this.phaseTimeout = setTimeout(() => {
                this.nextPhase();
            }, holdDuration * 1000);
        } else {
            // Skip hold phase if duration is 0
            this.nextPhase();
        }
    }
    
    animateCircle(phase, duration) {
        if (!this.circle) return;
        
        this.circle.classList.remove('inhale', 'exhale', 'hold');
        
        // Force reflow to ensure class removal takes effect
        this.circle.offsetHeight;
        
        if (phase === 'inhale') {
            this.circle.classList.add('inhale');
        } else if (phase === 'exhale') {
            this.circle.classList.add('exhale');
        } else if (phase === 'hold') {
            // Keep current state for hold phases
        }
        
        // Update transition duration
        this.circle.style.transitionDuration = `${duration}s`;
    }
    
    updateProgress() {
        if (!this.progressRing || !this.circumference) return;
        
        const totalPhases = this.totalCycles * 4; // inhale, holdIn, exhale, holdOut per cycle
        const currentPhaseNumber = (this.currentCycle * 4) + this.getPhaseNumber();
        const progress = currentPhaseNumber / totalPhases;
        
        const offset = this.circumference - (progress * this.circumference);
        this.progressRing.style.strokeDashoffset = offset;
    }
    
    getPhaseNumber() {
        switch (this.currentPhase) {
            case 'inhale': return 1;
            case 'holdIn': return 2;
            case 'exhale': return 3;
            case 'holdOut': return 4;
            default: return 0;
        }
    }
    
    updateCycleCounter() {
        if (this.cycleCounter) {
            this.cycleCounter.textContent = this.currentCycle;
        }
    }
    
    completeExercise() {
        this.isActive = false;
        this.completedExercises++;
        localStorage.setItem('breathingExercisesCompleted', this.completedExercises.toString());
        
        this.resetVisuals();
        this.updateUI();
        this.updateText('Exercise Complete!');
        
        // Update activity counter if available
        if (window.activityCounts) {
            window.activityCounts.breathing++;
            if (window.updateCounters) window.updateCounters();
            if (window.saveCounters) window.saveCounters();
        }
        
        // Show completion message
        this.showCompletionMessage();
        
        // Track completion
        this.trackEvent('breathing_exercise_completed', {
            total_cycles: this.totalCycles,
            pattern: this.breathingPattern
        });
        
        // Trigger activity count update if function exists
        if (typeof showEncouragement === 'function') {
            showEncouragement('breathing');
        }
    }
    
    showCompletionMessage() {
        const messages = [
            "Well done! You've completed your breathing exercise.",
            "Great job! Your mind and body are now more relaxed.",
            "Excellent! You've taken an important step for your mental wellness.",
            "Wonderful! Regular breathing exercises can reduce stress and anxiety.",
            "Amazing! You're building a healthy habit for better mental health."
        ];
        
        const randomMessage = messages[Math.floor(Math.random() * messages.length)];
        
        if (window.MindCareAI && window.MindCareAI.utils) {
            window.MindCareAI.utils.showToast(randomMessage, 'success', 5000);
        } else {
            this.showMessage(randomMessage);
        }
        
        // Create a more elaborate completion notification
        this.createCompletionEffect();
    }
    
    createCompletionEffect() {
        // Create floating hearts effect
        for (let i = 0; i < 5; i++) {
            setTimeout(() => {
                this.createFloatingHeart();
            }, i * 200);
        }
    }
    
    createFloatingHeart() {
        const heart = document.createElement('div');
        heart.innerHTML = '💙';
        heart.style.cssText = `
            position: fixed;
            font-size: 1.5rem;
            pointer-events: none;
            z-index: 9999;
            left: ${Math.random() * window.innerWidth}px;
            top: ${window.innerHeight}px;
            animation: floatUp 3s ease-out forwards;
        `;
        
        document.body.appendChild(heart);
        
        // Add floating animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes floatUp {
                0% {
                    transform: translateY(0) rotate(0deg);
                    opacity: 1;
                }
                100% {
                    transform: translateY(-${window.innerHeight + 100}px) rotate(360deg);
                    opacity: 0;
                }
            }
        `;
        
        if (!document.querySelector('style[data-floating-hearts]')) {
            style.setAttribute('data-floating-hearts', 'true');
            document.head.appendChild(style);
        }
        
        // Remove heart after animation
        setTimeout(() => {
            if (heart.parentNode) {
                heart.parentNode.removeChild(heart);
            }
        }, 3000);
    }
    
    resetVisuals() {
        if (this.circle) {
            this.circle.classList.remove('inhale', 'exhale', 'hold');
            this.circle.style.transitionDuration = '';
        }
        
        if (this.progressRing && this.circumference) {
            this.progressRing.style.strokeDashoffset = this.circumference;
        }
        
        this.updateCycleCounter();
    }
    
    updateUI() {
        if (this.startBtn && this.stopBtn) {
            if (this.isActive) {
                this.startBtn.style.display = 'none';
                this.stopBtn.style.display = 'inline-block';
            } else {
                this.startBtn.style.display = 'inline-block';
                this.stopBtn.style.display = 'none';
            }
        }
    }
    
    updateText(message) {
        if (this.text) {
            this.text.textContent = message;
        }
    }
    
    showMessage(message) {
        console.log('Breathing Exercise:', message);
        
        if (window.MindCareAI && window.MindCareAI.utils) {
            window.MindCareAI.utils.showToast(message, 'info', 3000);
        }
    }
    
    trackEvent(eventName, data = {}) {
        // Basic event tracking
        console.log(`Breathing Exercise Event: ${eventName}`, data);
        
        // Could integrate with analytics here
        if (typeof gtag !== 'undefined') {
            gtag('event', eventName, {
                event_category: 'breathing_exercise',
                ...data
            });
        }
    }
    
    // Public methods for external control
    setCycles(cycles) {
        if (!this.isActive && cycles > 0 && cycles <= 20) {
            this.totalCycles = cycles;
            this.saveSettings();
            this.showMessage(`Cycles set to ${cycles}`);
        }
    }
    
    getStats() {
        return {
            completedExercises: this.completedExercises,
            currentPattern: this.breathingPattern,
            isActive: this.isActive,
            currentCycle: this.currentCycle,
            totalCycles: this.totalCycles
        };
    }
    
    reset() {
        this.stop();
        this.currentCycle = 0;
        this.resetVisuals();
        this.updateText('Ready to begin');
    }
}

// Global breathing exercise instance
let breathingExercise = null;

// Initialize breathing exercise
function initBreathingExercise() {
    if (!breathingExercise) {
        breathingExercise = new BreathingExercise();
    }
    return breathingExercise;
}

// Functions called from HTML
function startBreathing() {
    const exercise = initBreathingExercise();
    exercise.start();
}

function stopBreathing() {
    if (breathingExercise) {
        breathingExercise.stop();
    }
}

function resetBreathing() {
    if (breathingExercise) {
        breathingExercise.reset();
    }
}

// Auto-initialize if elements are present
document.addEventListener('DOMContentLoaded', function() {
    const breathingCircle = document.getElementById('breathingCircle');
    if (breathingCircle) {
        initBreathingExercise();
    }
});

// Export for global access
window.BreathingExercise = BreathingExercise;
window.initBreathingExercise = initBreathingExercise;
window.startBreathing = startBreathing;
window.stopBreathing = stopBreathing;

console.log('Breathing Exercise module loaded');
